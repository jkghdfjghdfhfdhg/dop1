import { useState } from "react";
import "./App.css";

function App() {
  const [state, setState] = useState(0);

  return (
    <div className="App">
      <div
        className="counter"
        style={{
          display: "flex",
          gap: "10px",
          alignItems: "center",
        }}>
        <button className="minus" onClick={() => setState(state - 1)}>
          -
        </button>
        <div className="count">{state}</div>
        <button
          className="plus"
          onClick={() => {
            setState(state + 1);
            console.log(state);
          }}>
          +
        </button>
      </div>
    </div>
  );
}

export default App;
